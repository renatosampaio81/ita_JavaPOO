
public interface Embaralhador {
    String embaralhar(String palavra);
    int getDificuldade();
}
