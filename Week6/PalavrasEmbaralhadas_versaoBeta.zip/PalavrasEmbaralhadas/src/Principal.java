import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        BancoDePalavras bancoDePalavras = new BancoDePalavras();
        FabricaEmbaralhadores fabricaEmbaralhadores = new FabricaEmbaralhadores();
        FabricaMecanicaDoJogo fabricaMecanicaDoJogo = new FabricaMecanicaDoJogo();

        Embaralhador embaralhador = fabricaEmbaralhadores.getEmbaralhadorAleatorio();

        System.out.println("Escolha o modo de jogo:");
        System.out.println("1 - Padrão          (fim de jogo = 03 erros)");
        System.out.println("2 - Limite de Tempo (fim de jogo = 30 segundos)");

        int opcao;
        do {
            System.out.print("Digite sua opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            if (opcao != 1 && opcao != 2) {
                System.out.println("Opção inválida. Tente novamente.");
            }
        } while (opcao != 1 && opcao != 2);

        String tipoMecanica = (opcao == 2) ? "limite_tempo" : "padrao";

        MecanicaDoJogo mecanicaDoJogo = fabricaMecanicaDoJogo.getMecanicaDoJogo(bancoDePalavras, embaralhador, tipoMecanica);

        while (!mecanicaDoJogo.isFimDeJogo()) {
            System.out.println("Palavra embaralhada: " + mecanicaDoJogo.getPalavraEmbaralhada());
            System.out.print("Tente adivinhar a palavra: ");
            String resposta = scanner.nextLine();

            if (mecanicaDoJogo.tentarAcertar(resposta)) {
                System.out.println("\nParabéns! Você acertou.\n");
            } else {
                System.out.println("\nVocê errou.\n");
            }
        }

        System.out.println("Fim de jogo!");
        System.out.println("Pontuação final: " + mecanicaDoJogo.getPontuacao());

        scanner.close();
    }
}
